package team13.cardquest;

public class BlobQuest{
	String name;
	int stages;
	String namedFoe;

	public BlobQuest(String name, int stages, String namedFoe){
		this.name = name;
		this.stages = stages;
		this.namedFoe = namedFoe;
	}
}