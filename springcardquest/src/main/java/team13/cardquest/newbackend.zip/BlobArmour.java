package team13.cardquest;

public class BlobArmour {
    int value;
	int power;

	public BlobArmour(int value, int power){
		this.value = value;
		this.power = power;
	}
}