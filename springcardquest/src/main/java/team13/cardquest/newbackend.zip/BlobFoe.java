package team13.cardquest;

public class BlobFoe {
    String name;
	int power;
	int boost;

	public BlobFoe(String name, int power, int boost){
		this.name = name;
		this.power = power;
		this.boost = boost;
	}
}
