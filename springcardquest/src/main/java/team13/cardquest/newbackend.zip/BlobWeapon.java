package team13.cardquest;

public class BlobWeapon {
    String name;
	int power;

	public BlobWeapon(String name, int power){
		this.name = name;
		this.power = power;
	}
}
