package team13.cardquest;

public class BlobTest{
	String name;
	int minBid;

	public BlobTest(String name, int minBid){
		this.name = name;
		this.minBid = minBid;
	}
}