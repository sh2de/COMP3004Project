package team13.cardquest;

public class BlobEvent{
    String name;

	public BlobEvent(String name){
		this.name = name;
	}
}