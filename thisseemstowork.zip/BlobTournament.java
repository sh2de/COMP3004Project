package team13.cardquest;

public class BlobTournament{
	String name;
	int shields;

	public BlobTournament(String name, int shields){
		this.name = name;
		this.shields = shields;
	}
}