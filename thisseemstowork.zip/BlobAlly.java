package team13.cardquest;

public class BlobAlly {
    String name;
	int power;
	int value;

	public BlobAlly(String name, int power, int value){
		this.name = name;
		this.power = power;
		this.value = value;
	}
}
