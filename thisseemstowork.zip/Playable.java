package team13.cardquest;

public interface Playable{
	public void OnPlay();
}